# cairn resource pack

Custom models for the grave Item Display (`cairn:grave`) and the transferable key
(`cairn:grave_key`).

## Install

- Client: open the zip (`../cairn-resourcepack.zip` or rebuild from this folder) in
  Resource Packs, or copy this directory into `.minecraft/resourcepacks/cairn`.
- Testbed: `testbed/resourcepacks/cairn-resourcepack.zip` is a copy for local use.
- Server force-pack: point `resource-pack=` in `server.properties` at a hosted URL
  of the zip if you want every join to prompt for it.

Without this pack, graves still work: the display shows a stone item and the key
is a named tripwire hook.
